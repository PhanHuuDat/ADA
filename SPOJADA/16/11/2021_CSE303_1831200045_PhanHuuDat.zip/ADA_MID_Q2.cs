﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPOJADA
{
    class ADA_MID_Q2
    {
        static Reader reader = new Reader();

        static void Main(string[] args)
        {
            int male = reader.NextInt();
            int female = reader.NextInt();
            int X = reader.NextInt();

            List<int> males = new List<int>();
            List<int> females = new List<int>();

            for (int ind = 0; ind < male; ind++)
            {
                males.Add(reader.NextInt());
            }

            for (int ind = 0; ind < female; ind++)
            {
                females.Add(reader.NextInt());
            }

            males.Sort();
            females.Sort();

            int difference;
            List<int> differences = new List<int>();
            int i = 0;
            int j = 0;

            while (i > 0 && j > 0)
            {
                difference = Math.Abs(males[i] - females[j]);
                if ()
                {

                }
                i++;
                j++;
                differences.Add(difference);
            }
            differences.Sort();
            Console.WriteLine(differences[X - 1]);
        }
    }

    class Reader
    {
        private int index = 0;
        private string[] tokens;
        public string Next()
        {
            while (tokens == null || tokens.Length <= index)
            {
                tokens = Console.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                index = 0;
            }
            return tokens[index++];
        }

        public int NextInt()
        {
            return int.Parse(Next());
        }
        public long NextLong()
        {
            return long.Parse(Next());
        }
        public double NextDouble()
        {
            return double.Parse(Next());
        }
    }

}
