﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPOJADA
{
    class ADA_MID_Q1
    {
        static Reader reader = new Reader();

        static void Main(string[] args)
        {
            int arrayLength = reader.NextInt();
            int pair = reader.NextInt();
            List<int> list = new List<int>();
            int result = 0;

            for (int i = 0; i < arrayLength; i++)
            {
                int number = reader.NextInt();
                list.Add(number);
            }

            for (int i = 0; i < list.Count - 1; i++)
            {

                for (int j = i + 1; j < list.Count; j++)
                {
                    int cal = list[j] - list[i];
                    if (cal == pair)
                    {
                        result++;
                    }
                    
                }

            }
            Console.WriteLine(result);
        }


    }

    class Reader
    {
        private int index = 0;
        private string[] tokens;
        public string Next()
        {
            while (tokens == null || tokens.Length <= index)
            {
                tokens = Console.ReadLine().Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                index = 0;
            }
            return tokens[index++];
        }

        public int NextInt()
        {
            return int.Parse(Next());
        }
        public long NextLong()
        {
            return long.Parse(Next());
        }
        public double NextDouble()
        {
            return double.Parse(Next());
        }
    }

}
